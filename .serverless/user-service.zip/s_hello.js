
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'blacklab',
  applicationName: 'jaime',
  appUid: 'hQBQLGYvwdzMDySJBC',
  orgUid: '6c3a2bf7-9a2e-4141-9372-9aeaa032bbe9',
  deploymentUid: '99303c4a-0134-42cf-adb4-b188a20a92a9',
  serviceName: 'user-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'user-service-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}